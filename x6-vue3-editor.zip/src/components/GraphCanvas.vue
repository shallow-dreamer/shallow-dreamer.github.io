
<template>
  <div class="graph-container" ref="container" />
</template>
<script>
import { onMounted, onBeforeUnmount, ref } from 'vue';
import GraphService from '../services/graphService';
import PalettePlugin from '../plugins/palettePlugin';
import HistoryPlugin from '../plugins/historyPlugin';
import basicNode from '../x6/nodes/basicNode';

export default {
  setup() {
    const container = ref(null);
    onMounted(() => {
      const graph = GraphService.init(container.value);
      GraphService.use(new PalettePlugin());
      GraphService.use(new HistoryPlugin());
      graph.addNode({ shape:'rect', x:40, y:40, width:160, height:40, attrs:{ body:{ rx:6, fill:'#fff' }, label:{ text:'Welcome' } } });
    });
    onBeforeUnmount(() => GraphService.dispose());
    return { container };
  }
};
</script>
