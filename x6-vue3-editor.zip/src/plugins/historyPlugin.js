
import PluginBase from './pluginBase';
export default class HistoryPlugin extends PluginBase {
  init(graph, api) {
    this.graph = graph; this.api = api;
    this.stack = []; this.index = -1;
    this.pushSnapshot();
    graph.on('cell:added', () => this.pushSnapshot());
    graph.on('cell:removed', () => this.pushSnapshot());
    graph.on('cell:changed', () => this.pushSnapshot());
  }
  pushSnapshot() {
    const snap = this.graph.toJSON();
    if (this.index < this.stack.length - 1) this.stack.splice(this.index+1);
    this.stack.push(snap); this.index = this.stack.length -1;
  }
  undo() { if (this.index > 0) { this.index--; this.graph.fromJSON(this.stack[this.index]); } }
  redo() { if (this.index < this.stack.length -1) { this.index++; this.graph.fromJSON(this.stack[this.index]); } }
}
