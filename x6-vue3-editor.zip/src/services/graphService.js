
import { Graph } from '@antv/x6';
import registry from '../x6/registry';
import serializer from '../utils/serializer';
import { reactive } from 'vue';

class GraphService {
  constructor() {
    this.graph = null;
    this.plugins = [];
    this.state = reactive({ ready:false, selection:[] });
    this._nodeRegistry = registry;
    this.eventBus = new Map();
  }
  init(container, options = {}) {
    if (this.graph) return this.graph;
    this.graph = new Graph({ container, grid:{ size:10, visible:true }, ...options });
    this._nodeRegistry.registerAll(this.graph);
    this.graph.on('selection:changed', ({ nodes }) => {
      this.state.selection = (nodes || []).map(n => n.id);
      this.emit('selection:changed', this.state.selection);
    });
    this.plugins.forEach(p => p.init && p.init(this.graph, this.api()));
    this.state.ready = true;
    return this.graph;
  }
  api() {
    return {
      addNode: (nodeData) => {
        const cell = serializer.domainToCell(nodeData);
        return this.graph.addNode(cell);
      },
      getSelection: () => this.state.selection.slice(),
      getCell: (id) => this.graph.getCellById ? this.graph.getCellById(id) : this.graph.getCell(id),
      toJSON: () => serializer.serializeGraph(this.graph),
      fromJSON: (data) => serializer.deserializeGraph(this.graph, data),
      use: (plugin) => this.use(plugin),
      on: (evt, handler) => this.on(evt, handler),
      off: (evt, handler) => this.off(evt, handler),
      graph: this.graph
    };
  }
  use(plugin) {
    this.plugins.push(plugin);
    if (this.graph && plugin.init) plugin.init(this.graph, this.api());
  }
  on(evt, handler) {
    if (!this.eventBus.has(evt)) this.eventBus.set(evt, new Set());
    this.eventBus.get(evt).add(handler);
  }
  off(evt, handler) {
    const s = this.eventBus.get(evt);
    if (s) s.delete(handler);
  }
  emit(evt, payload) {
    const s = this.eventBus.get(evt);
    if (s) for (const h of s) h(payload);
  }
  dispose() {
    if (this.graph) {
      this.graph.dispose();
      this.graph = null;
      this.state.ready = false;
      this.plugins.forEach(p => p.onDestroy && p.onDestroy());
      this.plugins = [];
    }
  }
}

export default new GraphService();
