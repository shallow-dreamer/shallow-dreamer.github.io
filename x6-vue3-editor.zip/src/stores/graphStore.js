
import { defineStore } from 'pinia';
import GraphService from '../services/graphService';
export const useGraphStore = defineStore('graph', {
  state: () => ({ ready:false, currentDocId:null, autosave:true, lastSavedAt:null }),
  actions: {
    setReady(v=true) { this.ready = v; }
  }
});
