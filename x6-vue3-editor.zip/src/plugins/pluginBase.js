
export default class PluginBase {
  constructor(options = {}) { this.options = options; }
  init(graph, api) {}
  onDestroy() {}
}
