
<template>
  <aside class="node-editor" v-if="selectedNode">
    <h3>属性 - {{ selectedNode.id }}</h3>
    <label>标签</label>
    <input v-model="local.label" />
    <label>元数据 (JSON)</label>
    <textarea v-model="local.meta" rows="6"></textarea>
    <div class="actions">
      <button @click="apply">应用</button>
      <button @click="reset">重置</button>
    </div>
  </aside>
</template>
<script>
import { ref } from 'vue';
import GraphService from '../services/graphService';
export default {
  setup() {
    const selectedNode = ref(null);
    const local = ref({ label:'', meta:'{}' });
    GraphService.on('selection:changed', (ids) => {
      if (ids.length) {
        const cell = GraphService.api().getCell(ids[0]);
        selectedNode.value = cell;
        const label = cell.attr ? (cell.attr('label')?.text || '') : (cell.attrs && cell.attrs.label && cell.attrs.label.text) || '';
        local.value.label = label;
        local.value.meta = JSON.stringify(cell.data || {}, null, 2);
      } else selectedNode.value = null;
    });
    function apply() {
      if (!selectedNode.value) return;
      try {
        const meta = JSON.parse(local.value.meta);
        if (selectedNode.value.attr) selectedNode.value.attr('label/text', local.value.label);
        else if (selectedNode.value.setAttrs) selectedNode.value.setAttrs({ label:{ text: local.value.label }});
        selectedNode.value.setData ? selectedNode.value.setData(meta) : (selectedNode.value.data = meta);
      } catch (err) { alert('JSON 解析错误: ' + err.message); }
    }
    function reset() { /* simplified */ }
    return { selectedNode, local, apply, reset };
  }
};
</script>
