
<template>
  <div class="toolbar">
    <button @click="exportJson">导出 JSON</button>
    <button @click="undo">撤销</button>
    <button @click="redo">重做</button>
  </div>
</template>
<script>
import GraphService from '../services/graphService';
export default {
  setup() {
    function exportJson() {
      const json = GraphService.api().toJSON();
      const s = JSON.stringify(json, null, 2);
      const blob = new Blob([s], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'graph.json';
      a.click();
    }
    function undo() { GraphService.emit('cmd:undo'); }
    function redo() { GraphService.emit('cmd:redo'); }
    return { exportJson, undo, redo };
  }
};
</script>
