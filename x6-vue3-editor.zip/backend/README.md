
Django app 'graphs' skeleton. Integrate into your Django project:
- Add 'graphs' to INSTALLED_APPS
- Include graphs.urls in your project urls
- Configure DRF and authentication
