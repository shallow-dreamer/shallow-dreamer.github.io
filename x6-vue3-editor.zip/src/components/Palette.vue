
<template>
  <div class="palette">
    <div class="item" v-for="t in types" :key="t" draggable="true"
         @dragstart="onDragStart($event, t)">{{ t }}</div>
  </div>
</template>
<script>
export default {
  setup() {
    const types = ['basic-node'];
    function onDragStart(e, type) { e.dataTransfer.setData('application/x-node-type', type); }
    return { types, onDragStart };
  }
};
</script>
