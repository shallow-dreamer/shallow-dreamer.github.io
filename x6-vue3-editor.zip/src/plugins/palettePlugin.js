
import PluginBase from './pluginBase';
export default class PalettePlugin extends PluginBase {
  init(graph, api) {
    this.graph = graph; this.api = api;
    document.addEventListener('drop', this.onDrop);
    document.addEventListener('dragover', e => e.preventDefault());
  }
  onDrop = (e) => {
    const nodeType = e.dataTransfer.getData('application/x-node-type');
    if (!nodeType) return;
    const rect = this.graph.container.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    this.api.addNode({ id: `n_${Date.now()}`, type: nodeType, x, y, label: nodeType });
  };
  onDestroy() {
    document.removeEventListener('drop', this.onDrop);
  }
}
