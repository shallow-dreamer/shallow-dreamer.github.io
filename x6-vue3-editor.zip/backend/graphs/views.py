
from rest_framework import viewsets, permissions
from .models import GraphDocument
from .serializers import GraphDocumentSerializer
class GraphDocumentViewSet(viewsets.ModelViewSet):
    queryset = GraphDocument.objects.all()
    serializer_class = GraphDocumentSerializer
    permission_classes = [permissions.IsAuthenticated]
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)
