
from rest_framework import serializers
from .models import GraphDocument
class GraphDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = GraphDocument
        fields = ['id','name','owner','content','created_at','updated_at']
        read_only_fields = ['owner','created_at','updated_at']
