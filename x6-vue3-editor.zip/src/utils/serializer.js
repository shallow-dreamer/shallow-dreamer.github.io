
export default {
  domainToCell(domain) {
    return {
      id: domain.id || `n_${Date.now()}`,
      shape: domain.type || 'basic-node',
      x: domain.x || 40, y: domain.y || 40,
      width: domain.width || 160, height: domain.height || 40,
      attrs: { label: { text: domain.label || 'Node' } },
      data: domain.data || {}
    };
  },
  serializeGraph(graph) {
    const json = graph.toJSON();
    return json;
  },
  deserializeGraph(graph, json) {
    graph.clear && graph.clear();
    graph.fromJSON(json);
  }
};
