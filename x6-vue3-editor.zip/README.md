
# x6-vue3-editor - Minimal Example

This repository contains a minimal Vue 3 + @antv/x6 front-end and a small Django backend example.
It's intended as a starting point; you should install dependencies and adapt versions to your environment.

## Frontend
- `npm install`
- `npm run dev`

## Backend (Django)
Create a Django project and include the provided `backend/graphs` app files. Migrations and settings (DB, S3) need to be configured.

