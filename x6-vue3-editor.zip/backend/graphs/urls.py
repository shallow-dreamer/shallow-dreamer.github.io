
from rest_framework.routers import DefaultRouter
from .views import GraphDocumentViewSet
router = DefaultRouter()
router.register(r'graphs', GraphDocumentViewSet)
urlpatterns = router.urls
