
<template>
  <div id="app">
    <Toolbar />
    <div class="layout">
      <Palette />
      <GraphCanvas />
      <NodeEditor />
    </div>
  </div>
</template>

<script>
import Toolbar from './components/Toolbar.vue';
import Palette from './components/Palette.vue';
import GraphCanvas from './components/GraphCanvas.vue';
import NodeEditor from './components/NodeEditor.vue';

export default {
  components: { Toolbar, Palette, GraphCanvas, NodeEditor }
};
</script>
