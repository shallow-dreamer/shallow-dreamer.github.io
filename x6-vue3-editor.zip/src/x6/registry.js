
const nodeModules = [];
export default {
  register(nodeModule) { nodeModules.push(nodeModule); },
  registerAll(graph) {
    nodeModules.forEach(m => {
      if (typeof m.register === 'function') m.register(graph);
    });
  }
};
