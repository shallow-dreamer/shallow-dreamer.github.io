
import registry from '../registry';
const module = {
  register(graph) {
    if (graph.registerNode) {
      graph.registerNode('basic-node', {
        shape: 'rect', width:160, height:40,
        attrs: { body:{ rx:6, ry:6, stroke:'#5F95FF', fill:'#EFF4FF'}, label:{ text:'Basic', fill:'#262626', fontSize:14 } },
        ports: { groups: { in:{ position:'top' }, out:{ position:'bottom' } } }
      });
    } else if (graph.defineNode) {
      graph.defineNode('basic-node', { /* fallback */ });
    }
  }
};
registry.register(module);
export default module;
